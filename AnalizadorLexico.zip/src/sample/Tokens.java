package sample;

public enum Tokens {
  Trig,
  Numero_Entero,
  N_Euler,
  Variable,
  Linea,
  Logaritmo,
  Logaritmo_Natural,
  Raiz,
  Parentesis_Apertura,
  Parentesis_Cierre,
  Corchete_Apertura,
  Corchete_Cierre,
  Suma,
  Resta,
  Multiplicacion,
  División,
  Exponenciacion,
  Coma,
  Derivada,
  Asignacion,
  F_Trigonometrica,
  Limite,
  Tiende_A,
  Numero_Decimal,
  ERROR
}
